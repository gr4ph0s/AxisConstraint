#ifndef MAIN_H__
#define MAIN_H__

#include "c4d_basedocument.h"


Bool RegisterSnapTool();



#endif // MAIN_H__
